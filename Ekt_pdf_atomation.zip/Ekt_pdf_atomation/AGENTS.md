# Project notes

- Python project managed with `uv` (Python 3.12 at `C:\Program Files\Python312`). PyMuPDF is the PDF engine.
- Corporate TLS proxy: pass `--system-certs` to `uv add` / `uv sync` when downloading packages.
- Run tests: `uv run pytest -q`
- Portable install (no uv): `requirements.txt` / `requirements-dev.txt` + `setup.bat` / `run_api.bat`.
  When dependencies change, re-export the pins with
  `uv export --format requirements-txt --no-hashes --no-dev --no-emit-project` and keep both files in sync.
  `.bat` files must keep CRLF line endings.
- CLI: `uv run pdf-inspector inspect <pdf>` / `uv run pdf-inspector compare <expected> <actual>`
- Web API: `uv run pdf-inspector-api` (FastAPI app in `pdf_inspector/api.py`, http://127.0.0.1:8000, `/docs`)
- PyMuPDF on Windows: a failed `pymupdf.open` keeps the file locked while its exception/traceback is alive;
  release it (leave the except block, `gc.collect()`) before deleting the file.
