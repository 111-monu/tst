"""Command line interface.

    pdf-inspector inspect "C:\\path\\file.pdf"                                   -> also writes file_marked.pdf
    pdf-inspector compare "C:\\path\\expected.pdf" "C:\\path\\actual.pdf"   -> also writes actual_diff.pdf
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

from .comparer import Tolerances, compare_pdfs
from .extractor import read_pdf
from .highlighter import write_diff_pdf, write_inspection_pdf
from .report import comparison_to_dict, document_to_dict, format_comparison, format_document, to_json


def _emit(text: str, json_text: str, json_path: str | None) -> None:
    print(text)
    if json_path:
        Path(json_path).write_text(json_text, encoding="utf-8")
        print(f"\nJSON report written to {json_path}")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="pdf-inspector", description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--tables", choices=["lines", "text"], default="lines",
                        help="table detection: 'lines' for ruled tables, 'text' for borderless tables")
    sub = parser.add_subparsers(dest="command", required=True)

    p_inspect = sub.add_parser("inspect", help="report margins, fonts, tables, text and numbers of one PDF")
    p_inspect.add_argument("pdf")
    p_inspect.add_argument("--json", help="write full JSON report to this file")
    p_inspect.add_argument("--chars", action="store_true", help="include per-character details in JSON")
    p_inspect.add_argument("--output-pdf", help="new PDF with font/margin and table comments "
                                                "(default: <pdf>_marked.pdf)")
    p_inspect.add_argument("--no-pdf", action="store_true", help="do not create the marked PDF")

    p_compare = sub.add_parser("compare", help="compare numbers, text and tables of two PDFs "
                                               "(exit code 1 when they differ)")
    p_compare.add_argument("expected")
    p_compare.add_argument("actual")
    p_compare.add_argument("--json", help="write JSON diff report to this file")
    p_compare.add_argument("--output-pdf", help="new PDF with differences highlighted (default: <actual>_diff.pdf)")
    p_compare.add_argument("--no-pdf", action="store_true", help="do not create the highlighted PDF")
    p_compare.add_argument("--table-tol", type=float, default=0.01, help="table spacing tolerance in inches")

    args = parser.parse_args(argv)
    if args.command == "inspect":
        doc = read_pdf(args.pdf, args.tables)
        _emit(format_document(doc), to_json(document_to_dict(doc, args.chars)), args.json)
        if not args.no_pdf:
            print(f"\nMarked PDF written to {write_inspection_pdf(doc, args.output_pdf)}")
        return 0

    result = compare_pdfs(args.expected, args.actual, Tolerances(args.table_tol), args.tables)
    _emit(format_comparison(result), to_json(comparison_to_dict(result)), args.json)
    if not args.no_pdf:
        print(f"\nHighlighted PDF written to {write_diff_pdf(result, args.output_pdf)}")
    return 0 if result.identical else 1


if __name__ == "__main__":
    sys.exit(main())
