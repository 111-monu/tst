"""Compare two PDFs (given as path strings) and report number, text and table differences.

Fonts and margins are not compared. Anything inside a table is reported only as a table difference;
outside tables, changed numbers are number differences and a text difference is reported only when the
words of a line (ignoring its numbers) changed.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from difflib import SequenceMatcher
from typing import Any

from .extractor import NUMBER_RE, Box, DocumentInfo, PageInfo, TableInfo, read_pdf

CATEGORIES = ("page", "table", "text", "number")


@dataclass
class Tolerances:
    table_in: float = 0.01


@dataclass
class Difference:
    category: str
    page: int | None
    location: str
    expected: Any
    actual: Any
    detail: str = ""
    bbox: Box | None = None  # where to mark it on the actual page (inches)
    group: str = ""  # differences with the same page + group are shown in one box

    @property
    def removed(self) -> bool:
        return self.expected is not None and self.actual is None


@dataclass
class ComparisonResult:
    expected_path: str
    actual_path: str
    differences: list[Difference] = field(default_factory=list)

    @property
    def identical(self) -> bool:
        return not self.differences

    def by_category(self) -> dict[str, list[Difference]]:
        return {c: [d for d in self.differences if d.category == c] for c in CATEGORIES}

    def summary(self) -> dict[str, int]:
        return {c: len(v) for c, v in self.by_category().items()}


def _to_float(value: str) -> float | None:
    try:
        return float(value.replace(",", "").replace("$", "").replace("%", ""))
    except ValueError:
        return None


def _number_change(a: str, b: str) -> str:
    fa, fb = _to_float(a), _to_float(b)
    return f"Change: {fb - fa:+g}" if fa is not None and fb is not None else ""


def _union(boxes: list[Box]) -> Box | None:
    if not boxes:
        return None
    return (min(b[0] for b in boxes), min(b[1] for b in boxes), max(b[2] for b in boxes), max(b[3] for b in boxes))


def _inside(box: Box, outer: Box) -> bool:
    return outer[0] <= box[0] and outer[1] <= box[1] and box[2] <= outer[2] and box[3] <= outer[3]


def _outside_tables(items: list[str], boxes: list[Box], tables: list[TableInfo]) -> tuple[list[str], list[Box]]:
    def in_table(b: Box) -> bool:
        cx, cy = (b[0] + b[2]) / 2, (b[1] + b[3]) / 2
        return any(t.bbox[0] <= cx <= t.bbox[2] and t.bbox[1] <= cy <= t.bbox[3] for t in tables)

    keep = [i for i, b in enumerate(boxes) if not in_table(b)]
    return [items[i] for i in keep], [boxes[i] for i in keep]


def _char_changes(a: str, b: str) -> str:
    parts = []
    for op, i1, i2, j1, j2 in SequenceMatcher(None, a, b, autojunk=False).get_opcodes():
        if op != "equal":
            parts.append(f"{op} col {i1 + 1}: '{a[i1:i2]}' -> '{b[j1:j2]}'")
    return "; ".join(parts)


def _compare_sequences(category: str, page: int, a: list[str], b: list[str], label: str,
                       boxes_a: list[Box], boxes_b: list[Box], keys_a: list[str] | None = None,
                       keys_b: list[str] | None = None) -> list[Difference]:
    """Diff two ordered lists. ``keys_*`` (default: the items) are what is actually compared."""
    diffs = []
    sm = SequenceMatcher(None, keys_a if keys_a is not None else a, keys_b if keys_b is not None else b,
                         autojunk=False)
    for op, i1, i2, j1, j2 in sm.get_opcodes():
        if op == "equal":
            continue
        if op == "replace" and i2 - i1 == j2 - j1:
            for k in range(i2 - i1):
                va, vb = a[i1 + k], b[j1 + k]
                detail = _number_change(va, vb) if category == "number" else _char_changes(va, vb)
                diffs.append(Difference(category, page, f"{label} {i1 + k + 1}", va, vb, detail, boxes_b[j1 + k]))
            continue
        # Removed items no longer exist in the actual PDF: mark where they were in the expected one.
        box = _union(boxes_b[j1:j2]) if j2 > j1 else _union(boxes_a[i1:i2])
        detail = {"insert": "added", "delete": "removed"}.get(op, "changed")
        diffs.append(Difference(category, page, f"{label} {i1 + 1}", a[i1:i2] or None, b[j1:j2] or None,
                                detail, box))
    return diffs


def _compare_table(page: int, ta: TableInfo, tb: TableInfo, tol: float) -> list[Difference]:
    name = f"Table {ta.index + 1}"
    group = f"{name} layout"
    diffs: list[Difference] = []

    def layout(location: str, va, vb, detail: str = "") -> None:
        diffs.append(Difference("table", page, f"{name} {location}", va, vb, detail, tb.bbox, group))

    def measure(location: str, va: float, vb: float) -> None:
        if abs(va - vb) > tol:
            layout(location, va, vb, f"delta {vb - va:+.4f} in")

    for side in ("top", "bottom", "left", "right"):
        measure(f"margin {side}", getattr(ta.margins, side), getattr(tb.margins, side))
    for attr, label in (("row_count", "rows"), ("col_count", "columns")):
        if getattr(ta, attr) != getattr(tb, attr):
            layout(label, getattr(ta, attr), getattr(tb, attr))

    for attr, fmt in (("row_heights", "row {i} height"), ("row_gaps", "gap rows {i}-{j}"),
                      ("column_widths", "column {i} width"), ("column_gaps", "gap columns {i}-{j}")):
        la, lb = getattr(ta, attr), getattr(tb, attr)
        if len(la) != len(lb):
            layout(attr.replace("_", " "), la, lb, "different count")
            continue
        for i, (va, vb) in enumerate(zip(la, lb)):
            measure(fmt.format(i=i + 1, j=i + 2), va, vb)

    pad_b = {(p.row, p.col): p for p in tb.cell_padding}
    for pa in ta.cell_padding:
        pb = pad_b.get((pa.row, pa.col))
        if pb:
            for side in ("top", "bottom", "left", "right"):
                measure(f"cell r{pa.row + 1}c{pa.col + 1} padding {side}", getattr(pa, side), getattr(pb, side))

    for r, (row_a, row_b) in enumerate(zip(ta.cells_text, tb.cells_text)):
        for c, (va, vb) in enumerate(zip(row_a, row_b)):
            if va == vb:
                continue
            box = tb.cell_boxes[r][c] if r < len(tb.cell_boxes) and c < len(tb.cell_boxes[r]) else None
            detail = _number_change(va, vb) if va and vb else ""
            diffs.append(Difference("table", page, f"{name}, row {r + 1}, column {c + 1}", va, vb,
                                    detail or _char_changes(va, vb), box or tb.bbox))
    return diffs


def _compare_page_content(pa: PageInfo, pb: PageInfo) -> list[Difference]:
    n = pa.number
    lines_a, lboxes_a = _outside_tables(pa.lines, pa.line_boxes, pa.tables)
    lines_b, lboxes_b = _outside_tables(pb.lines, pb.line_boxes, pb.tables)
    text = _compare_sequences("text", n, lines_a, lines_b, "Line", lboxes_a, lboxes_b,
                              [NUMBER_RE.sub("#", ln) for ln in lines_a], [NUMBER_RE.sub("#", ln) for ln in lines_b])

    nums_a, nboxes_a = _outside_tables(pa.numbers, pa.number_boxes, pa.tables)
    nums_b, nboxes_b = _outside_tables(pb.numbers, pb.number_boxes, pb.tables)
    numbers = _compare_sequences("number", n, nums_a, nums_b, "Number", nboxes_a, nboxes_b)
    # Added/removed lines already cover the numbers they contain.
    whole_lines = [d.bbox for d in text if d.detail in ("added", "removed") and d.bbox]
    numbers = [d for d in numbers
               if not (d.detail in ("added", "removed") and d.bbox and any(_inside(d.bbox, w) for w in whole_lines))]
    return text + numbers


def compare_documents(a: DocumentInfo, b: DocumentInfo, tol: Tolerances | None = None) -> ComparisonResult:
    tol = tol or Tolerances()
    result = ComparisonResult(a.path, b.path)
    d = result.differences
    if a.page_count != b.page_count:
        d.append(Difference("page", None, "Page count", a.page_count, b.page_count))

    for pa, pb in zip(a.pages, b.pages):
        n = pa.number
        if abs(pa.width - pb.width) > tol.table_in or abs(pa.height - pb.height) > tol.table_in:
            d.append(Difference("page", n, "Page size (in)", (pa.width, pa.height), (pb.width, pb.height)))
        if len(pa.tables) != len(pb.tables):
            d.append(Difference("table", n, "Table count", len(pa.tables), len(pb.tables)))
        for ta, tb in zip(pa.tables, pb.tables):
            d += _compare_table(n, ta, tb, tol.table_in)
        d += _compare_page_content(pa, pb)
    return result


def compare_pdfs(expected_path: str, actual_path: str, tol: Tolerances | None = None,
                 table_strategy: str = "lines") -> ComparisonResult:
    """Compare two PDFs given as path strings. ``expected_path`` is the baseline."""
    return compare_documents(read_pdf(expected_path, table_strategy), read_pdf(actual_path, table_strategy), tol)
