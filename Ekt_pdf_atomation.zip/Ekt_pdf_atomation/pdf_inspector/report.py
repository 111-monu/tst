"""Human-readable and JSON renderings of inspection and comparison results."""
from __future__ import annotations

import json
from dataclasses import asdict

from .comparer import ComparisonResult
from .extractor import DocumentInfo


def document_to_dict(doc: DocumentInfo, include_chars: bool = False) -> dict:
    data = asdict(doc)
    if not include_chars:
        for page in data["pages"]:
            page.pop("chars")
    return data


def comparison_to_dict(result: ComparisonResult) -> dict:
    return {
        "expected": result.expected_path,
        "actual": result.actual_path,
        "identical": result.identical,
        "summary": result.summary(),
        "differences": [asdict(d) for d in result.differences],
    }


def to_json(data: dict) -> str:
    return json.dumps(data, indent=2, ensure_ascii=False, default=str)


def format_document(doc: DocumentInfo) -> str:
    out = [f"PDF: {doc.path}", f"Pages: {doc.page_count}", "", "Fonts used (font, size, style, characters):"]
    for f in doc.fonts_summary:
        style = "".join(["B" if f["bold"] else "", "I" if f["italic"] else ""]) or "regular"
        out.append(f"  {f['font']:<30} {f['size']:>6}pt  {style:<8} {f['characters']}")
    for p in doc.pages:
        out += ["", f"--- Page {p.number} ({p.width} x {p.height} in) ---"]
        m = p.margins
        out.append(f"  Margins (in): top={m.top} bottom={m.bottom} left={m.left} right={m.right}"
                   if m else "  Margins: page is empty")
        out.append(f"  Text lines: {len(p.lines)}   Numbers: {len(p.numbers)}   Tables: {len(p.tables)}")
        for t in p.tables:
            tm = t.margins
            out.append(f"  Table {t.index + 1}: {t.row_count} rows x {t.col_count} cols, "
                       f"margins (in) top={tm.top} bottom={tm.bottom} left={tm.left} right={tm.right}")
            out.append(f"    row heights (in):   {t.row_heights}")
            out.append(f"    row gaps (in):      {t.row_gaps}")
            out.append(f"    column widths (in): {t.column_widths}")
            out.append(f"    column gaps (in):   {t.column_gaps}")
            for cp in t.cell_padding:
                out.append(f"    cell r{cp.row + 1}c{cp.col + 1} padding (in): "
                           f"top={cp.top} bottom={cp.bottom} left={cp.left} right={cp.right}")
    return "\n".join(out)


def format_comparison(result: ComparisonResult) -> str:
    out = [f"Expected: {result.expected_path}", f"Actual:   {result.actual_path}", ""]
    if result.identical:
        return "\n".join(out + ["No differences found."])
    out.append("Summary: " + ", ".join(f"{k}={v}" for k, v in result.summary().items()))
    for category, diffs in result.by_category().items():
        if not diffs:
            continue
        out += ["", f"== {category.upper()} differences ({len(diffs)}) =="]
        for d in diffs:
            page = f"p{d.page}" if d.page else "doc"
            line = f"  [{page}] {d.location}: {d.expected!r} -> {d.actual!r}"
            out.append(line + (f"  ({d.detail})" if d.detail else ""))
    return "\n".join(out)
