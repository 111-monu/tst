"""Read a PDF (given as a path string) and extract layout, font, table, text and number information.

All distances are reported in inches (1 inch = 72 PDF points). Font sizes are reported in points.
"""
from __future__ import annotations

import re
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path
from statistics import median

import pymupdf

pymupdf.no_recommend_layout()

POINTS_PER_INCH = 72.0
NUMBER_RE = re.compile(r"[-+]?\$?(?:\d[\d,]*(?:\.\d+)?|\.\d+)%?")


Box = tuple[float, float, float, float]  # x0, y0, x1, y1 in inches from the page's top-left corner


def to_in(points: float) -> float:
    return round(points / POINTS_PER_INCH, 4)


def rect_in(rect) -> tuple[float, float, float, float]:
    return tuple(to_in(v) for v in rect)


@dataclass
class Margins:
    top: float
    bottom: float
    left: float
    right: float


@dataclass
class CharInfo:
    char: str
    font: str
    size: float
    bold: bool
    italic: bool
    color: str
    x: float
    y: float
    bbox: Box

    @property
    def style(self) -> tuple:
        return self.font, self.size, self.bold, self.italic, self.color


@dataclass
class FontSpan:
    text: str
    font: str
    size: float
    bold: bool
    italic: bool
    monospace: bool
    serif: bool
    color: str
    bbox: tuple[float, float, float, float]


@dataclass
class CellPadding:
    row: int
    col: int
    top: float
    bottom: float
    left: float
    right: float
    cell_bbox: Box


@dataclass
class TableInfo:
    index: int
    bbox: tuple[float, float, float, float]
    margins: Margins
    row_count: int
    col_count: int
    row_heights: list[float]
    column_widths: list[float]
    row_gaps: list[float]
    column_gaps: list[float]
    cell_padding: list[CellPadding]
    cells_text: list[list[str]]
    cell_boxes: list[list[Box | None]] = field(default_factory=list)


@dataclass
class PageInfo:
    number: int
    width: float
    height: float
    margins: Margins | None = None
    spans: list[FontSpan] = field(default_factory=list)
    chars: list[CharInfo] = field(default_factory=list)
    tables: list[TableInfo] = field(default_factory=list)
    lines: list[str] = field(default_factory=list)
    line_boxes: list[Box] = field(default_factory=list)
    numbers: list[str] = field(default_factory=list)
    number_boxes: list[Box] = field(default_factory=list)


@dataclass
class DocumentInfo:
    path: str
    page_count: int
    pages: list[PageInfo]
    fonts_summary: list[dict] = field(default_factory=list)


def _resolve_path(path: str) -> Path:
    p = Path(str(path).strip().strip('"').strip("'")).expanduser()
    if not p.is_file():
        raise FileNotFoundError(f"PDF not found: {p}")
    return p


def _style_flags(font: str, flags: int) -> dict:
    name = font.lower()
    return {
        "bold": bool(flags & pymupdf.TEXT_FONT_BOLD) or "bold" in name or "black" in name or "heavy" in name,
        "italic": bool(flags & pymupdf.TEXT_FONT_ITALIC) or "italic" in name or "oblique" in name,
        "monospace": bool(flags & pymupdf.TEXT_FONT_MONOSPACED),
        "serif": bool(flags & pymupdf.TEXT_FONT_SERIFED),
    }


def _color_hex(color: int) -> str:
    return f"#{color:06x}"


def _union_in(rects: list) -> tuple[float, float, float, float]:
    r = pymupdf.Rect(rects[0])
    for other in rects[1:]:
        r |= other
    return rect_in(r)


def _extract_text_info(page: pymupdf.Page, info: PageInfo) -> list[pymupdf.Rect]:
    """Fill spans, chars, lines and numbers of ``info``; return the boxes of all visible glyphs."""
    rects: list[pymupdf.Rect] = []
    raw = page.get_text("rawdict", flags=pymupdf.TEXTFLAGS_RAWDICT & ~pymupdf.TEXT_PRESERVE_IMAGES)
    for block in raw["blocks"]:
        for line in block.get("lines", []):
            line_chars = []
            for span in line["spans"]:
                line_chars += span["chars"]
                text = "".join(c["c"] for c in span["chars"])
                if not text.strip():
                    continue
                style = _style_flags(span["font"], span["flags"])
                size = round(span["size"], 2)
                color = _color_hex(span["color"])
                info.spans.append(FontSpan(text, span["font"], size, color=color, bbox=rect_in(span["bbox"]),
                                           **style))
                for c in span["chars"]:
                    if c["c"].strip():
                        rects.append(pymupdf.Rect(c["bbox"]))
                    info.chars.append(CharInfo(c["c"], span["font"], size, style["bold"], style["italic"], color,
                                               to_in(c["origin"][0]), to_in(c["origin"][1]),
                                               rect_in(c["bbox"])))
            line_text = "".join(c["c"] for c in line_chars)
            if not line_text.strip():
                continue
            info.lines.append(line_text.strip())
            info.line_boxes.append(_union_in([c["bbox"] for c in line_chars if c["c"].strip()]))
            for m in NUMBER_RE.finditer(line_text):
                info.numbers.append(m.group())
                info.number_boxes.append(_union_in([c["bbox"] for c in line_chars[m.start():m.end()]]))
    return rects


def _content_rects(page: pymupdf.Page, text_rects: list[pymupdf.Rect]) -> list[pymupdf.Rect]:
    page_rect = page.rect
    page_area = page_rect.get_area()
    rects = list(text_rects)
    rects += [pymupdf.Rect(img["bbox"]) for img in page.get_image_info()]
    for d in page.get_drawings():
        r = pymupdf.Rect(d["rect"])
        # Skip full-page backgrounds/borders so they do not hide real margins.
        if r.width == 0 and r.height == 0 or r.get_area() >= 0.95 * page_area:
            continue
        rects.append(r)
    clipped = []
    for r in rects:
        r = r & page_rect
        if r.width > 0 or r.height > 0:
            clipped.append(r)
    return clipped


def _margins(page: pymupdf.Page, rects: list[pymupdf.Rect]) -> Margins | None:
    if not rects:
        return None
    x0 = min(r.x0 for r in rects)
    y0 = min(r.y0 for r in rects)
    x1 = max(r.x1 for r in rects)
    y1 = max(r.y1 for r in rects)
    pr = page.rect
    return Margins(top=to_in(y0 - pr.y0), bottom=to_in(pr.y1 - y1), left=to_in(x0 - pr.x0), right=to_in(pr.x1 - x1))


def _extract_tables(page: pymupdf.Page, strategy: str) -> list[TableInfo]:
    words = page.get_text("words")
    pr = page.rect
    tables = []
    for t_index, table in enumerate(page.find_tables(strategy=strategy).tables):
        rows = table.rows
        row_heights = [to_in(r.bbox[3] - r.bbox[1]) for r in rows]
        row_gaps = [to_in(rows[i + 1].bbox[1] - rows[i].bbox[3]) for i in range(len(rows) - 1)]

        col_x0: list[list[float]] = [[] for _ in range(table.col_count)]
        col_x1: list[list[float]] = [[] for _ in range(table.col_count)]
        padding: list[CellPadding] = []
        for r_idx, row in enumerate(rows):
            for c_idx, cell in enumerate(row.cells):
                if cell is None:
                    continue
                cx0, cy0, cx1, cy1 = cell
                col_x0[c_idx].append(cx0)
                col_x1[c_idx].append(cx1)
                inside = [w for w in words
                          if cx0 <= (w[0] + w[2]) / 2 <= cx1 and cy0 <= (w[1] + w[3]) / 2 <= cy1]
                if inside:
                    padding.append(CellPadding(
                        row=r_idx, col=c_idx,
                        top=to_in(min(w[1] for w in inside) - cy0),
                        bottom=to_in(cy1 - max(w[3] for w in inside)),
                        left=to_in(min(w[0] for w in inside) - cx0),
                        right=to_in(cx1 - max(w[2] for w in inside)),
                        cell_bbox=rect_in(cell),
                    ))

        bounds = [(median(a), median(b)) if a else None for a, b in zip(col_x0, col_x1)]
        column_widths = [to_in(b[1] - b[0]) if b else 0.0 for b in bounds]
        column_gaps = [to_in(bounds[i + 1][0] - bounds[i][1]) if bounds[i] and bounds[i + 1] else 0.0
                       for i in range(len(bounds) - 1)]
        bx0, by0, bx1, by1 = table.bbox
        tables.append(TableInfo(
            index=t_index,
            bbox=rect_in(table.bbox),
            margins=Margins(top=to_in(by0 - pr.y0), bottom=to_in(pr.y1 - by1),
                            left=to_in(bx0 - pr.x0), right=to_in(pr.x1 - bx1)),
            row_count=table.row_count,
            col_count=table.col_count,
            row_heights=row_heights,
            column_widths=column_widths,
            row_gaps=row_gaps,
            column_gaps=column_gaps,
            cell_padding=padding,
            cells_text=[[(c or "").strip() for c in row] for row in table.extract()],
            cell_boxes=[[rect_in(c) if c else None for c in row.cells] for row in rows],
        ))
    return tables


def page_font_summary(page: PageInfo, sample_len: int = 40) -> list[dict]:
    """Distinct font styles used on one page, most used first, each with a short sample text."""
    usage: Counter = Counter()
    samples: dict[tuple, str] = {}
    for s in page.spans:
        key = (s.font, s.size, s.bold, s.italic, s.color)
        usage[key] += len(s.text.strip())
        samples.setdefault(key, s.text.strip()[:sample_len])
    return [{"font": f, "size": sz, "bold": b, "italic": i, "color": c, "characters": n, "sample": samples[key]}
            for key, n in usage.most_common() for f, sz, b, i, c in [key]]


def read_pdf(path: str, table_strategy: str = "lines") -> DocumentInfo:
    """Read the PDF at ``path`` (a string) and return all extracted information.

    ``table_strategy`` is ``"lines"`` (ruled tables) or ``"text"`` (tables without borders).
    """
    pdf_path = _resolve_path(path)
    pages: list[PageInfo] = []
    font_usage: Counter = Counter()
    with pymupdf.open(pdf_path) as doc:
        for page in doc:
            info = PageInfo(number=page.number + 1, width=to_in(page.rect.width), height=to_in(page.rect.height))
            text_rects = _extract_text_info(page, info)
            info.margins = _margins(page, _content_rects(page, text_rects))
            info.tables = _extract_tables(page, table_strategy)
            for s in info.spans:
                font_usage[(s.font, s.size, s.bold, s.italic)] += len(s.text)
            pages.append(info)
        page_count = doc.page_count
    summary = [{"font": f, "size": s, "bold": b, "italic": i, "characters": n}
               for (f, s, b, i), n in font_usage.most_common()]
    return DocumentInfo(path=str(pdf_path), page_count=page_count, pages=pages, fonts_summary=summary)
