"""PDF inspector: margins (inches), fonts, characters, tables, text and numbers - read and compare PDFs."""
from .comparer import ComparisonResult, Difference, Tolerances, compare_documents, compare_pdfs
from .extractor import DocumentInfo, read_pdf
from .highlighter import write_diff_pdf, write_inspection_pdf
from .report import comparison_to_dict, document_to_dict, format_comparison, format_document

__all__ = [
    "ComparisonResult", "Difference", "DocumentInfo", "Tolerances", "compare_documents", "compare_pdfs",
    "comparison_to_dict", "document_to_dict", "format_comparison", "format_document", "read_pdf",
    "write_diff_pdf", "write_inspection_pdf",
]
