"""Create new PDF files with comments on the pages. The original PDFs are never modified.

- ``write_inspection_pdf``: per page one sticky-note comment with fonts + margins, one sticky note per table
  with its measurements; margins, tables and cell text areas are drawn as plain graphics.
- ``write_diff_pdf``: on a copy of the *actual* PDF, a box (with comment) around every number, text and table
  difference.
"""
from __future__ import annotations

from pathlib import Path

import pymupdf

from .comparer import ComparisonResult, Difference
from .extractor import POINTS_PER_INCH, Box, DocumentInfo, PageInfo, TableInfo, page_font_summary

COLORS = {
    "page": (0.4, 0.4, 0.4),
    "table": (0.6, 0.0, 0.8),
    "text": (0.9, 0.0, 0.0),
    "number": (0.0, 0.6, 0.0),
}
MARGIN_COLOR = (0.0, 0.35, 1.0)
PADDING_COLOR = (0.0, 0.6, 0.6)
NOTE_SIZE = 20  # points, approximate size of a sticky-note icon


def _rect(box: Box) -> pymupdf.Rect:
    return pymupdf.Rect(*(v * POINTS_PER_INCH for v in box))


def _default_output(source: str, suffix: str) -> str:
    p = Path(source)
    return str(p.with_name(f"{p.stem}_{suffix}.pdf"))


def _check_output(output_path: str, *inputs: str) -> None:
    if Path(output_path).resolve() in {Path(i).resolve() for i in inputs}:
        raise ValueError("output_path must be a new file, not one of the input PDFs")


def _sticky_note(page: pymupdf.Page, x: float, y: float, title: str, content: str) -> None:
    r = page.rect
    point = pymupdf.Point(min(max(x, r.x0), r.x1 - NOTE_SIZE), min(max(y, r.y0), r.y1 - NOTE_SIZE))
    annot = page.add_text_annot(point, content, icon="Comment")
    annot.set_info(title=title, content=content)
    annot.update()


def _box(page: pymupdf.Page, box: Box, color, title: str, content: str, dashed: bool = False) -> None:
    annot = page.add_rect_annot(_rect(box) + (-1.5, -1.5, 1.5, 1.5))
    annot.set_colors(stroke=color)
    annot.set_border(width=1.2, dashes=[3, 2] if dashed else None)
    annot.set_info(title=title, content=content)
    annot.update()


# ---------------------------------------------------------------- comparison output

def _value(v) -> str:
    if isinstance(v, list):
        return " | ".join(str(x) for x in v)
    return "-" if v is None else str(v)


def _describe(d: Difference) -> str:
    if d.detail == "added":
        return f"{d.location} added:\n{_value(d.actual)}"
    if d.detail == "removed":
        return f"{d.location} removed:\n{_value(d.expected)}"
    text = f"{d.location}\nExpected: {_value(d.expected)}\nActual: {_value(d.actual)}"
    return text + (f"\n{d.detail}" if d.detail else "")


def _describe_layout(group: str, items: list[Difference]) -> str:
    prefix = group.removesuffix(" layout") + " "
    lines = [f"{group} differences (inches)"]
    for d in items:
        detail = f" ({d.detail})" if d.detail else ""
        lines.append(f"{d.location.removeprefix(prefix)}: {_value(d.expected)} -> {_value(d.actual)}{detail}")
    return "\n".join(lines)


def write_diff_pdf(result: ComparisonResult, output_path: str | None = None) -> str:
    """Write a copy of the *actual* PDF with a commented box around every difference. Returns the new path."""
    output_path = output_path or _default_output(result.actual_path, "diff")
    _check_output(output_path, result.actual_path, result.expected_path)

    with pymupdf.open(result.actual_path) as doc:
        boxed: dict[tuple, list[Difference]] = {}
        unplaced: dict[int, list[Difference]] = {}
        for d in result.differences:
            page_no = d.page if d.page and d.page <= doc.page_count else 1
            if d.bbox and d.page and d.page <= doc.page_count:
                key = (page_no, d.group or tuple(round(v, 3) for v in d.bbox))
                boxed.setdefault(key, []).append(d)
            elif doc.page_count:
                unplaced.setdefault(page_no, []).append(d)

        for (page_no, key), items in boxed.items():
            first = items[0]
            if first.group:
                title, content = first.group, _describe_layout(first.group, items)
            else:
                title, content = f"{first.category.capitalize()} difference", "\n\n".join(map(_describe, items))
            _box(doc[page_no - 1], first.bbox, COLORS[first.category], title, content, dashed=first.removed)

        for page_no, items in unplaced.items():
            _sticky_note(doc[page_no - 1], 10, 10, "Other differences", "\n\n".join(map(_describe, items)))
        doc.save(output_path, garbage=3, deflate=True)
    return output_path


# ---------------------------------------------------------------- single PDF output

def _style(f: dict) -> str:
    return " ".join(s for s, on in (("Bold", f["bold"]), ("Italic", f["italic"])) if on) or "Regular"


def _fonts_margins_note(p: PageInfo) -> str:
    lines = [f"Page size: {p.width:.3f} x {p.height:.3f} in", ""]
    if p.margins is None:
        return "\n".join(lines + ["No content on this page"])
    m = p.margins
    lines += ["Margins (inches)",
              f"Top: {m.top:.3f}   Bottom: {m.bottom:.3f}   Left: {m.left:.3f}   Right: {m.right:.3f}", "", "Fonts"]
    for f in page_font_summary(p):
        lines.append(f"- {f['font']} {f['size']}pt {_style(f)} {f['color']} - {f['characters']} chars - "
                     f"\"{f['sample']}\"")
    return "\n".join(lines)


def _join(values: list[float], fmt) -> str:
    return ", ".join(f"{fmt(i)} {v:.3f}" for i, v in enumerate(values)) or "-"


def _table_note(t: TableInfo) -> str:
    m = t.margins
    lines = [f"{t.row_count} rows x {t.col_count} columns (all values in inches)",
             f"Table margins: Top {m.top:.3f}  Bottom {m.bottom:.3f}  Left {m.left:.3f}  Right {m.right:.3f}",
             f"Row heights: {_join(t.row_heights, lambda i: f'R{i + 1}')}",
             f"Gaps between rows: {_join(t.row_gaps, lambda i: f'R{i + 1}-R{i + 2}')}",
             f"Column widths: {_join(t.column_widths, lambda i: f'C{i + 1}')}",
             f"Gaps between columns: {_join(t.column_gaps, lambda i: f'C{i + 1}-C{i + 2}')}",
             "", "Cell padding (top / bottom / left / right):"]
    lines += [f"R{c.row + 1}C{c.col + 1}: {c.top:.3f} / {c.bottom:.3f} / {c.left:.3f} / {c.right:.3f}"
              for c in t.cell_padding] or ["-"]
    return "\n".join(lines)


def _draw_marks(page: pymupdf.Page, p: PageInfo) -> None:
    """Margin lines, table outlines and cell text areas as plain page graphics (not comments)."""
    if not page.is_wrapped:
        page.wrap_contents()
    m = p.margins
    if m:
        w, h, k = page.rect.width, page.rect.height, POINTS_PER_INCH
        lines = {"top": ((0, m.top * k), (w, m.top * k)),
                 "bottom": ((0, h - m.bottom * k), (w, h - m.bottom * k)),
                 "left": ((m.left * k, 0), (m.left * k, h)),
                 "right": ((w - m.right * k, 0), (w - m.right * k, h))}
        for side, (a, b) in lines.items():
            page.draw_line(a, b, color=MARGIN_COLOR, width=0.6, dashes="[3 2] 0")
            label_at = (a[0] + 2, a[1] - 2) if side in ("top", "bottom") else (a[0] + 2, 8)
            page.insert_text(label_at, f"{side} {getattr(m, side):.3f}in", fontname="helv", fontsize=6,
                             color=MARGIN_COLOR)
    for t in p.tables:
        page.draw_rect(_rect(t.bbox) + (-1.5, -1.5, 1.5, 1.5), color=COLORS["table"], width=1)
        for c in t.cell_padding:
            x0, y0, x1, y1 = c.cell_bbox
            page.draw_rect(_rect((x0 + c.left, y0 + c.top, x1 - c.right, y1 - c.bottom)), color=PADDING_COLOR,
                           width=0.6)


def write_inspection_pdf(info: DocumentInfo, output_path: str | None = None) -> str:
    """Write a copy of one PDF with a Fonts & Margins comment per page and one comment per table."""
    output_path = output_path or _default_output(info.path, "marked")
    _check_output(output_path, info.path)

    with pymupdf.open(info.path) as doc:
        for p in info.pages:
            page = doc[p.number - 1]
            _draw_marks(page, p)
            note_x, note_y = page.rect.width - NOTE_SIZE - 4, 4
            _sticky_note(page, note_x, note_y, f"Page {p.number} - Fonts & Margins", _fonts_margins_note(p))
            for t in p.tables:
                r = _rect(t.bbox)
                x, y = r.x1 + 2, r.y0
                if abs(x - note_x) < NOTE_SIZE and abs(y - note_y) < NOTE_SIZE:
                    y = note_y + NOTE_SIZE + 4
                _sticky_note(page, x, y, f"Page {p.number} - Table {t.index + 1}", _table_note(t))
        doc.save(output_path, garbage=3, deflate=True)
    return output_path
