"""FastAPI web service: upload PDFs, get the processed PDF (or JSON) back.

    uv run pdf-inspector-api            -> http://127.0.0.1:8000  (upload page)  /docs (Swagger UI)

POST /inspect   file                 -> <name>_marked.pdf  (Fonts & Margins + Table comments)
POST /compare   expected + actual    -> <actual>_diff.pdf  (boxed number / text / table differences)
Add ``output=json`` to get the JSON report instead of the PDF.
"""
from __future__ import annotations

import gc
import os
import re
import shutil
import tempfile
from enum import Enum
from pathlib import Path

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from starlette.background import BackgroundTask

from .comparer import Tolerances, compare_documents
from .extractor import read_pdf
from .highlighter import write_diff_pdf, write_inspection_pdf
from .report import comparison_to_dict, document_to_dict

MAX_UPLOAD_MB = float(os.environ.get("PDF_API_MAX_MB", "50"))
CHUNK = 1024 * 1024


class TableStrategy(str, Enum):
    lines = "lines"
    text = "text"


class OutputFormat(str, Enum):
    pdf = "pdf"
    json = "json"


app = FastAPI(title="PDF Inspector", version="0.1.0",
              description="Inspect one PDF (fonts, margins, tables as comments) or compare two PDFs "
                          "(number, text and table differences boxed on the actual PDF).")


def _safe_name(filename: str | None) -> str:
    name = re.sub(r"[^\w.\-]", "_", Path(filename or "").name).strip("._") or "upload"
    return name if name.lower().endswith(".pdf") else f"{name}.pdf"


def _save_upload(upload: UploadFile, folder: Path) -> Path:
    folder.mkdir(parents=True, exist_ok=True)
    target = folder / _safe_name(upload.filename)
    size, limit = 0, MAX_UPLOAD_MB * CHUNK
    with target.open("wb") as out:
        while chunk := upload.file.read(CHUNK):
            size += len(chunk)
            if size > limit:
                raise HTTPException(413, f"{upload.filename}: file larger than {MAX_UPLOAD_MB:g} MB")
            out.write(chunk)
    if size == 0:
        raise HTTPException(400, f"{upload.filename}: empty file")
    return target


def _read(path: Path, tables: TableStrategy, label: str):
    try:
        return read_pdf(str(path), tables.value)
    except Exception as exc:  # pymupdf raises various errors for damaged / non-PDF files
        error = f"{label} is not a readable PDF: {exc}"
    # The failed document is referenced by the exception traceback and keeps the file locked on Windows,
    # which would stop the temp folder from being deleted. Raise outside the except block and collect it.
    gc.collect()
    raise HTTPException(400, error)


def _respond(work: Path, output: OutputFormat, pdf_path: str, download_name: str, json_data: dict,
             headers: dict[str, str]):
    cleanup = BackgroundTask(shutil.rmtree, work, ignore_errors=True)
    if output is OutputFormat.json:
        return JSONResponse(json_data, headers=headers, background=cleanup)
    return FileResponse(pdf_path, media_type="application/pdf", filename=download_name, headers=headers,
                        background=cleanup)


@app.get("/", response_class=HTMLResponse, include_in_schema=False)
def upload_page() -> str:
    return UPLOAD_PAGE


@app.get("/health")
def health() -> dict:
    return {"status": "ok"}


@app.post("/inspect", summary="Upload one PDF, get it back with Fonts & Margins and Table comments")
def inspect(file: UploadFile = File(..., description="PDF to inspect"),
            tables: TableStrategy = Form(TableStrategy.lines, description="'text' for tables without borders"),
            output: OutputFormat = Form(OutputFormat.pdf)):
    work = Path(tempfile.mkdtemp(prefix="pdfapi_"))
    try:
        source = _save_upload(file, work / "in")
        info = _read(source, tables, file.filename or "file")
        out_name = f"{source.stem}_marked.pdf"
        out_pdf = write_inspection_pdf(info, str(work / out_name)) if output is OutputFormat.pdf else ""
        data = document_to_dict(info)
        data["path"] = file.filename
        return _respond(work, output, out_pdf, out_name, data, {"X-Pages": str(info.page_count)})
    except BaseException:
        shutil.rmtree(work, ignore_errors=True)
        raise


@app.post("/compare", summary="Upload expected + actual PDF, get the actual PDF back with differences boxed")
def compare(expected: UploadFile = File(..., description="Baseline / reference PDF"),
            actual: UploadFile = File(..., description="PDF to check; differences are boxed on this one"),
            tables: TableStrategy = Form(TableStrategy.lines, description="'text' for tables without borders"),
            table_tol: float = Form(0.01, ge=0, description="table spacing tolerance in inches"),
            output: OutputFormat = Form(OutputFormat.pdf)):
    work = Path(tempfile.mkdtemp(prefix="pdfapi_"))
    try:
        exp_path = _save_upload(expected, work / "expected")
        act_path = _save_upload(actual, work / "actual")
        result = compare_documents(_read(exp_path, tables, expected.filename or "expected"),
                                   _read(act_path, tables, actual.filename or "actual"), Tolerances(table_tol))
        out_name = f"{act_path.stem}_diff.pdf"
        out_pdf = write_diff_pdf(result, str(work / out_name)) if output is OutputFormat.pdf else ""
        data = comparison_to_dict(result)
        data["expected"], data["actual"] = expected.filename, actual.filename
        headers = {"X-Identical": str(result.identical).lower(), "X-Differences": str(len(result.differences))}
        return _respond(work, output, out_pdf, out_name, data, headers)
    except BaseException:
        shutil.rmtree(work, ignore_errors=True)
        raise


def run() -> None:
    import uvicorn

    uvicorn.run(app, host=os.environ.get("PDF_API_HOST", "127.0.0.1"), port=int(os.environ.get("PDF_API_PORT", "8000")))


UPLOAD_PAGE = """<!doctype html>
<html><head><meta charset="utf-8"><title>PDF Inspector</title>
<style>
 body{font-family:Segoe UI,Arial,sans-serif;max-width:760px;margin:40px auto;color:#222}
 form{border:1px solid #ccc;border-radius:8px;padding:18px 22px;margin-bottom:28px}
 h2{margin-top:0} label{display:block;margin:10px 0 4px;font-weight:600}
 button{margin-top:16px;padding:8px 18px;font-size:15px;cursor:pointer}
 small{color:#666}
</style></head><body>
<h1>PDF Inspector</h1>
<form action="/inspect" method="post" enctype="multipart/form-data">
 <h2>Inspect one PDF</h2>
 <small>Returns a copy with one Fonts &amp; Margins comment per page and one comment per table.</small>
 <label>PDF file</label><input type="file" name="file" accept="application/pdf,.pdf" required>
 <label>Table detection</label>
 <select name="tables"><option value="lines">Ruled tables (lines)</option>
 <option value="text">Tables without borders (text)</option></select>
 <label>Result</label>
 <select name="output"><option value="pdf">Commented PDF</option><option value="json">JSON report</option></select>
 <br><button type="submit">Inspect</button>
</form>
<form action="/compare" method="post" enctype="multipart/form-data">
 <h2>Compare two PDFs</h2>
 <small>Returns the actual PDF with number, text and table differences boxed (click a box for details).</small>
 <label>Expected (reference) PDF</label><input type="file" name="expected" accept="application/pdf,.pdf" required>
 <label>Actual PDF</label><input type="file" name="actual" accept="application/pdf,.pdf" required>
 <label>Table detection</label>
 <select name="tables"><option value="lines">Ruled tables (lines)</option>
 <option value="text">Tables without borders (text)</option></select>
 <label>Table tolerance (inches)</label><input type="number" name="table_tol" value="0.01" step="0.001" min="0">
 <label>Result</label>
 <select name="output"><option value="pdf">Highlighted PDF</option><option value="json">JSON report</option></select>
 <br><button type="submit">Compare</button>
</form>
<p><a href="/docs">API documentation (Swagger)</a></p>
</body></html>
"""
