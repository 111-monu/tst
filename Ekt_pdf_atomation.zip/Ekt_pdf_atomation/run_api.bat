@echo off
rem Starts the PDF Inspector web app. Run setup.bat once before the first start.
setlocal
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
    echo The environment is missing - run setup.bat first.
    pause
    exit /b 1
)

if not defined PDF_API_PORT set "PDF_API_PORT=8000"
echo.
echo Open http://127.0.0.1:%PDF_API_PORT% in your browser  (API docs: http://127.0.0.1:%PDF_API_PORT%/docs)
echo Press Ctrl+C in this window to stop the server.
echo.
".venv\Scripts\python.exe" -c "from pdf_inspector.api import run; run()"
pause
