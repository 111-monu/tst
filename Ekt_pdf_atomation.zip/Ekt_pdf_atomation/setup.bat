@echo off
rem One-time setup: creates a .venv folder next to this file and installs requirements.txt into it.
setlocal
cd /d "%~dp0"

rem Reuse an existing working environment (only if it has pip), otherwise (re)create it.
if exist ".venv\Scripts\python.exe" (
    ".venv\Scripts\python.exe" -m pip --version >nul 2>&1 && goto :install
)

set "PY=%PYTHON%"
if not defined PY (
    py -3 --version >nul 2>&1 && set "PY=py -3"
)
if not defined PY (
    python --version >nul 2>&1 && set "PY=python"
)
if not defined PY (
    echo.
    echo Python 3.10 or newer was not found.
    echo Install it from https://www.python.org/downloads/ ^(tick "Add python.exe to PATH"^),
    echo or point to it, e.g.:  set PYTHON="C:\Program Files\Python312\python.exe"
    goto :fail
)

%PY% -c "import sys; sys.exit(sys.version_info < (3, 10))" || (
    echo Python 3.10 or newer is required.
    goto :fail
)

echo Creating virtual environment in .venv ...
%PY% -m venv --clear .venv || goto :fail

:install
echo Installing packages from requirements.txt ...
".venv\Scripts\python.exe" -m pip install --upgrade pip
".venv\Scripts\python.exe" -m pip install -r requirements.txt || goto :fail

echo.
echo Setup complete.
echo   Web app : run_api.bat   then open http://127.0.0.1:8000
echo   CLI     : .venv\Scripts\python -m pdf_inspector --help
pause
exit /b 0

:fail
echo.
echo Setup failed - see the messages above.
pause
exit /b 1
