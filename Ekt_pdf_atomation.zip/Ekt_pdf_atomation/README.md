# pdf-inspector

Read a PDF from a path string (`inspect`), or compare two PDFs (`compare`).

`inspect` reports, per page:
1. **Page margins in inches** (top, bottom, left, right), measured from the edge of the page to the outermost text, image or drawing.
2. **Fonts**: font name, size (pt), bold/italic, color, character count and sample text.
3. **Tables**: row heights, gaps between rows, column widths and gaps, the table's margins from the page edges, and the padding inside each cell (text to cell border) on all four sides, all in inches.

`compare` checks **numbers, text and tables** only (fonts and margins are not compared):
- numbers outside tables (changed / added / removed, with the numeric change);
- text lines outside tables whose words changed (a line where only a number changed is a number difference);
- table cell values, and table layout (margins, row/column counts, row heights, gaps, column widths, cell padding).

## Run it on another computer (step by step)

### 1. Make the zip (on this computer)
Zip the project folder, but **leave these out**. They are machine-specific and get recreated by `setup.bat`:
`.venv\`, `.pytest_cache\`, every `__pycache__\` folder. You can also leave out your own PDFs.

The zip must contain:
```
pdf_inspector\        (the code)
tests\                (optional, for checking the install)
requirements.txt      requirements-dev.txt
setup.bat             run_api.bat
pyproject.toml        README.md
```

### 2. Install Python (once, on the other computer)
- Download **Python 3.10 or newer** from https://www.python.org/downloads/ (3.12 recommended).
- In the installer, tick **"Add python.exe to PATH"**.
- Check it in a new Command Prompt: `python --version`

### 3. Unzip and set up (once)
- Unzip the folder anywhere, e.g. `C:\Tools\Ekt_pdf_atomation`.
- Double-click **`setup.bat`**, or run it from a Command Prompt:
  ```
  cd C:\Tools\Ekt_pdf_atomation
  setup.bat
  ```
- It creates a `.venv` folder and installs everything from `requirements.txt` (internet needed).
- When it ends with "Setup complete", you're done.
- If Python is installed but not found, point to it and run setup again:
  ```
  set PYTHON="C:\Program Files\Python312\python.exe"
  setup.bat
  ```

### 4. Start the web app
- Double-click **`run_api.bat`**, then open **http://127.0.0.1:8000** in a browser.
- There you'll find the **Inspect one PDF** and **Compare two PDFs** upload forms; the result downloads automatically.
- **http://127.0.0.1:8000/docs** has the interactive API page.
- Keep the window open while using it; press **Ctrl+C** in it to stop.
- **Port 8000 already in use** (`[Errno 10048]`)? Start on another port:
  ```
  set PDF_API_PORT=8001
  run_api.bat
  ```

### 5. Command line (optional, no browser)
From the project folder:
```
.venv\Scripts\python -m pdf_inspector inspect "C:\path\file.pdf"
.venv\Scripts\python -m pdf_inspector compare "C:\path\expected.pdf" "C:\path\actual.pdf"
```

### 6. Check the install (optional)
```
.venv\Scripts\python -m pip install -r requirements-dev.txt
.venv\Scripts\python -m pytest -q
```

### Without the .bat files (Mac / Linux / manual)
```
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt          # Windows: .venv\Scripts\python
.venv/bin/python -c "from pdf_inspector.api import run; run()"
```

### Troubleshooting
- **SSL / certificate error during install** (company network): first run
  `.venv\Scripts\python -m pip install --upgrade pip`. Recent pip versions use the Windows certificate store.
  If it still fails, ask IT for the proxy settings.
- **Other computers should reach the web app:** `set PDF_API_HOST=0.0.0.0` before `run_api.bat`.
  There is no login, so only do this on a trusted network.

## Development setup (uv)

```
uv sync --system-certs
```

## Command line

```
uv run pdf-inspector inspect "C:\path\file.pdf" [--json report.json] [--chars]
uv run pdf-inspector compare "C:\path\expected.pdf" "C:\path\actual.pdf" [--json diff.json]
        [--table-tol 0.01]
uv run pdf-inspector --tables text compare ...   # for tables without borders
```

Without uv, use `.venv\Scripts\python -m pdf_inspector` instead of `uv run pdf-inspector`.

`compare` exits with code `1` when differences are found.

### New PDF files

- `inspect` writes **`<pdf>_marked.pdf`**: a copy with, on every page, **one sticky-note comment
  "Page N - Fonts & Margins"** and **one sticky-note comment per table "Page N - Table K"** with all table
  measurements. Margin lines, table outlines and cell text areas are also drawn (plain graphics, not comments).
- `compare` writes **`<actual>_diff.pdf`**: a copy of the actual PDF with a commented box around every
  difference: green = number, red = text, purple = table (one box per changed cell, one box per table for
  all its layout differences); dashed box = removed content. Differences without a position (page count,
  page size, table count) go into one "Other differences" sticky note. No pages are added.

The original PDFs are never modified. Use `--output-pdf "C:\path\new.pdf"` to choose the file name,
or `--no-pdf` to skip creating it.

## Web API (FastAPI)

```
uv run pdf-inspector-api        # http://127.0.0.1:8000  (upload page), /docs (Swagger UI)
```

Set `PDF_API_HOST`, `PDF_API_PORT`, `PDF_API_MAX_MB` (upload size limit, default 50) to change defaults.

| Endpoint | Form fields | Returns |
|---|---|---|
| `POST /inspect` | `file`, `tables` (`lines`/`text`), `output` (`pdf`/`json`) | `<name>_marked.pdf` download (or JSON) |
| `POST /compare` | `expected`, `actual`, `tables`, `table_tol`, `output` | `<actual>_diff.pdf` download (or JSON); headers `X-Identical`, `X-Differences` |

```
curl -F "file=@C:\path\file.pdf" http://127.0.0.1:8000/inspect -o file_marked.pdf
curl -F "expected=@expected.pdf" -F "actual=@actual.pdf" http://127.0.0.1:8000/compare -o actual_diff.pdf
```

Uploads are processed in a temporary folder that is deleted after the response is sent.

## Python

```python
from pdf_inspector import read_pdf, compare_pdfs, format_comparison, write_diff_pdf, write_inspection_pdf

doc = read_pdf(r"C:\path\file.pdf")
print(doc.pages[0].margins)           # Margins(top=..., bottom=..., left=..., right=...) in inches
print(doc.pages[0].tables[0].cell_padding)

result = compare_pdfs(r"C:\path\expected.pdf", r"C:\path\actual.pdf")
print(format_comparison(result))
for d in result.by_category()["number"]:
    print(d.page, d.expected, d.actual, d.detail)

write_diff_pdf(result, r"C:\path\differences.pdf")          # new highlighted PDF
write_inspection_pdf(doc, r"C:\path\file_marked.pdf")       # new marked-up copy of one PDF
```

Difference categories: `page`, `table`, `text`, `number`.
