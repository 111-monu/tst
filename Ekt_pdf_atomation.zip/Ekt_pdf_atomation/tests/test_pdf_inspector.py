from pathlib import Path

import pymupdf
import pytest

from pdf_inspector import compare_pdfs, read_pdf, write_diff_pdf, write_inspection_pdf
from pdf_inspector.cli import main

INCH = 72


def make_pdf(path: Path, *, left=1.0, top=1.0, font="helv", size=12, amount="1,250.00",
             title="Invoice Summary", row_height=0.4, cell_pad=0.1, price="10.50", with_table=True) -> str:
    """Letter page: a title line, a number line and a 3x2 ruled table. Dimensions in inches."""
    doc = pymupdf.open()
    page = doc.new_page(width=8.5 * INCH, height=11 * INCH)
    x, y = left * INCH, top * INCH
    page.insert_text((x, y + size), title, fontname=font, fontsize=size)
    page.insert_text((x, y + 40), f"Total due: {amount} USD", fontname="helv", fontsize=12)

    if with_table:
        tx0, ty0, col_w = x, y + 1.0 * INCH, 2.0 * INCH
        rows = [("Item", "Price"), ("Widget", price), ("Gadget", "20.75")]
        for r, row in enumerate(rows):
            for c, text in enumerate(row):
                cell = pymupdf.Rect(tx0 + c * col_w, ty0 + r * row_height * INCH,
                                    tx0 + (c + 1) * col_w, ty0 + (r + 1) * row_height * INCH)
                page.draw_rect(cell, color=(0, 0, 0), width=0.5)
                page.insert_text((cell.x0 + cell_pad * INCH, cell.y0 + cell_pad * INCH + 8), text,
                                 fontname="helv", fontsize=10)
    doc.save(path)
    return str(path)


def annotations(path: str) -> list[tuple[str, str, str, pymupdf.Rect]]:
    """(type, title, content, rect) of every annotation on page 1."""
    with pymupdf.open(path) as doc:
        page = doc[0]  # keep a page reference while iterating annots (pymupdf requirement)
        return [(a.type[1], a.info["title"], a.info["content"], a.rect) for a in page.annots()]


@pytest.fixture
def base(tmp_path):
    return make_pdf(tmp_path / "base.pdf")


# ---------------------------------------------------------------- extraction

def test_reads_margins_in_inches(base):
    page = read_pdf(base).pages[0]
    assert (page.width, page.height) == (8.5, 11.0)
    assert page.margins.left == pytest.approx(1.0, abs=0.02)
    assert page.margins.top == pytest.approx(1.0, abs=0.05)
    assert page.margins.right == pytest.approx(8.5 - 1.0 - 4.0, abs=0.02)


def test_reads_fonts_and_characters(base):
    doc = read_pdf(base)
    title = next(s for s in doc.pages[0].spans if s.text == "Invoice Summary")
    assert title.font == "Helvetica" and title.size == 12 and not title.bold
    assert "".join(c.char for c in doc.pages[0].chars).startswith("Invoice Summary")
    assert {f["font"] for f in doc.fonts_summary} == {"Helvetica"}


def test_reads_table_geometry(base):
    tables = read_pdf(base).pages[0].tables
    assert len(tables) == 1
    t = tables[0]
    assert (t.row_count, t.col_count) == (3, 2)
    assert t.row_heights == pytest.approx([0.4] * 3, abs=0.01)
    assert t.column_widths == pytest.approx([2.0, 2.0], abs=0.01)
    assert t.cells_text[1] == ["Widget", "10.50"]
    assert t.cell_padding[0].left == pytest.approx(0.1, abs=0.02)
    assert t.cell_boxes[1][1] == pytest.approx((3.0, 2.4, 5.0, 2.8), abs=0.01)


# ---------------------------------------------------------------- comparison

def test_identical_pdfs_have_no_differences(tmp_path, base):
    assert compare_pdfs(base, make_pdf(tmp_path / "same.pdf")).identical


def test_compare_ignores_font_and_margin(tmp_path):
    a = make_pdf(tmp_path / "a.pdf", with_table=False)
    b = make_pdf(tmp_path / "b.pdf", with_table=False, left=1.5, top=1.3, font="hebo", size=14)
    assert compare_pdfs(a, b).identical


def test_moved_table_reports_table_margins(tmp_path, base):
    layout = compare_pdfs(base, make_pdf(tmp_path / "b.pdf", left=1.5)).differences
    assert {d.location for d in layout} == {"Table 1 margin left", "Table 1 margin right"}


def test_number_change_outside_table_is_number_only(tmp_path, base):
    cats = compare_pdfs(base, make_pdf(tmp_path / "b.pdf", amount="1,350.00")).by_category()
    assert cats["text"] == [] and cats["table"] == []
    [num] = cats["number"]
    assert (num.expected, num.actual, num.detail) == ("1,250.00", "1,350.00", "Change: +100")


def test_text_word_change(tmp_path, base):
    cats = compare_pdfs(base, make_pdf(tmp_path / "b.pdf", title="Invoice Summery")).by_category()
    assert cats["number"] == [] and cats["table"] == []
    [text] = cats["text"]
    assert (text.expected, text.actual) == ("Invoice Summary", "Invoice Summery")


def test_table_cell_value_change(tmp_path, base):
    other = make_pdf(tmp_path / "b.pdf", price="11.50")
    result = compare_pdfs(base, other)
    cats = result.by_category()
    assert cats["number"] == [] and cats["text"] == []
    [cell] = cats["table"]
    assert (cell.location, cell.expected, cell.actual, cell.detail) == (
        "Table 1, row 2, column 2", "10.50", "11.50", "Change: +1")
    assert cell.bbox == read_pdf(other).pages[0].tables[0].cell_boxes[1][1]


def test_table_layout_changes_are_one_box(tmp_path, base):
    other = make_pdf(tmp_path / "b.pdf", row_height=0.5, cell_pad=0.15)
    result = compare_pdfs(base, other)
    layout = [d for d in result.differences if d.group == "Table 1 layout"]
    assert any("row 1 height" in d.location for d in layout)
    assert any("padding left" in d.location for d in layout)

    out = write_diff_pdf(result, str(tmp_path / "out.pdf"))
    boxes = [a for a in annotations(out) if a[1] == "Table 1 layout"]
    assert len(boxes) == 1 and boxes[0][0] == "Square"
    assert "row 1 height: 0.4 -> 0.5" in boxes[0][2] and "padding left" in boxes[0][2]


def test_diff_pdf_boxes_number_and_text_without_summary(tmp_path, base):
    other = make_pdf(tmp_path / "b.pdf", amount="1,350.00", title="Invoice Summery", font="hebo")
    result = compare_pdfs(base, other)
    out = write_diff_pdf(result, str(tmp_path / "out.pdf"))
    with pymupdf.open(out) as doc, pymupdf.open(other) as original:
        assert doc.page_count == original.page_count
    annots = annotations(out)
    assert {a[0] for a in annots} == {"Square"} and len(annots) == 2
    number = next(a for a in annots if a[1] == "Number difference")
    num_box = pymupdf.Rect(*(v * INCH for v in result.by_category()["number"][0].bbox))
    assert number[3].intersects(num_box) and "Expected: 1,250.00" in number[2] and "Actual: 1,350.00" in number[2]
    assert any(a[1] == "Text difference" and "Invoice Summery" in a[2] for a in annots)
    with pymupdf.open(other) as original:
        assert original[0].first_annot is None  # source untouched


def test_missing_table_goes_to_other_note(tmp_path, base):
    result = compare_pdfs(base, make_pdf(tmp_path / "b.pdf", with_table=False))
    out = write_diff_pdf(result, str(tmp_path / "out.pdf"))
    notes = [a for a in annotations(out) if a[1] == "Other differences"]
    assert len(notes) == 1 and notes[0][0] == "Text" and "Table count" in notes[0][2]


def test_diff_pdf_refuses_to_overwrite_input(base):
    with pytest.raises(ValueError):
        write_diff_pdf(compare_pdfs(base, base), base)


# ---------------------------------------------------------------- inspection PDF

def test_inspection_pdf_comments(tmp_path, base):
    out = write_inspection_pdf(read_pdf(base), str(tmp_path / "marked.pdf"))
    annots = annotations(out)
    assert [(a[0], a[1]) for a in annots] == [("Text", "Page 1 - Fonts & Margins"), ("Text", "Page 1 - Table 1")]
    fonts, table = annots[0][2], annots[1][2]
    assert "Left: 1.000" in fonts and "Helvetica 12.0pt Regular #000000" in fonts and '"Invoice Summary"' in fonts
    assert "3 rows x 2 columns" in table and "Row heights: R1 0.400" in table and "R1C1:" in table
    with pymupdf.open(base) as src, pymupdf.open(out) as marked:
        assert len(marked[0].get_drawings()) > len(src[0].get_drawings())  # marks drawn as graphics


def test_inspection_pdf_without_table_has_only_font_margin_note(tmp_path):
    pdf = make_pdf(tmp_path / "plain.pdf", with_table=False)
    annots = annotations(write_inspection_pdf(read_pdf(pdf)))
    assert [a[1] for a in annots] == ["Page 1 - Fonts & Margins"]


# ---------------------------------------------------------------- CLI

def test_cli_compare_exit_code_and_json(tmp_path, base, capsys):
    other = make_pdf(tmp_path / "b.pdf", amount="9.99")
    out_json = tmp_path / "diff.json"
    assert main(["compare", base, other, "--json", str(out_json)]) == 1
    out = capsys.readouterr().out
    assert out_json.exists() and "NUMBER differences" in out and "MARGIN" not in out and "FONT" not in out
    assert (tmp_path / "b_diff.pdf").exists()
    assert main(["inspect", base]) == 0
    assert (tmp_path / "base_marked.pdf").exists()


def test_missing_file_raises():
    with pytest.raises(FileNotFoundError):
        read_pdf(r"C:\does\not\exist.pdf")
