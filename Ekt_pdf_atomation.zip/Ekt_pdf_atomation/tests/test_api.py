import tempfile
from pathlib import Path

import pymupdf
import pytest
from fastapi.testclient import TestClient

from pdf_inspector.api import app
from test_pdf_inspector import make_pdf

client = TestClient(app)


def upload(path: str, name: str | None = None):
    return name or Path(path).name, Path(path).read_bytes(), "application/pdf"


def page_annots(pdf_bytes: bytes) -> list[str]:
    with pymupdf.open(stream=pdf_bytes, filetype="pdf") as doc:
        page = doc[0]
        return [a.info["title"] for a in page.annots()]


@pytest.fixture
def pdfs(tmp_path):
    return (make_pdf(tmp_path / "expected.pdf"),
            make_pdf(tmp_path / "actual.pdf", amount="1,300.00", price="11.50", title="Invoice Summery"))


def test_upload_page_and_health():
    assert "Compare two PDFs" in client.get("/").text
    assert client.get("/health").json() == {"status": "ok"}


def test_inspect_returns_commented_pdf(pdfs):
    r = client.post("/inspect", files={"file": upload(pdfs[0], "My Report.pdf")})
    assert r.status_code == 200 and r.headers["content-type"] == "application/pdf"
    assert 'filename="My_Report_marked.pdf"' in r.headers["content-disposition"]
    assert page_annots(r.content) == ["Page 1 - Fonts & Margins", "Page 1 - Table 1"]


def test_inspect_json(pdfs):
    r = client.post("/inspect", files={"file": upload(pdfs[0])}, data={"output": "json"})
    assert r.status_code == 200
    data = r.json()
    assert data["path"] == "expected.pdf" and data["pages"][0]["margins"]["left"] == pytest.approx(1.0, abs=0.02)


def test_compare_returns_highlighted_pdf(tmp_path, monkeypatch, pdfs):
    work = tmp_path / "work"
    work.mkdir()
    monkeypatch.setattr(tempfile, "tempdir", str(work))
    r = client.post("/compare", files={"expected": upload(pdfs[0]), "actual": upload(pdfs[1])})
    assert not list(work.glob("pdfapi_*"))  # temp files removed after the response was sent
    assert r.status_code == 200 and r.headers["x-identical"] == "false"
    assert 'filename="actual_diff.pdf"' in r.headers["content-disposition"]
    assert sorted(page_annots(r.content)) == ["Number difference", "Table difference", "Text difference"]


def test_compare_json_and_same_file_names(tmp_path, pdfs):
    r = client.post("/compare", data={"output": "json"},
                    files={"expected": upload(pdfs[0], "a.pdf"), "actual": upload(pdfs[0], "a.pdf")})
    assert r.status_code == 200 and r.json()["identical"] is True and r.headers["x-differences"] == "0"


def test_rejects_non_pdf_and_empty(tmp_path, monkeypatch):
    monkeypatch.setattr(tempfile, "tempdir", str(tmp_path))  # api temp folders are created here
    bad = client.post("/inspect", files={"file": ("notes.pdf", b"hello world", "application/pdf")})
    assert bad.status_code == 400 and "not a readable PDF" in bad.json()["detail"]
    assert not list(tmp_path.glob("pdfapi_*"))  # temp upload removed even though the PDF was invalid
    empty = client.post("/inspect", files={"file": ("e.pdf", b"", "application/pdf")})
    assert empty.status_code == 400


def test_rejects_invalid_option(pdfs):
    r = client.post("/inspect", files={"file": upload(pdfs[0])}, data={"tables": "magic"})
    assert r.status_code == 422
